const fs = require('fs');
const files = fs.readdirSync('GoogleAppsScript').filter(f => f.endsWith('.js.html') || f.endsWith('.html'));

for (const file of files) {
    let content = fs.readFileSync('GoogleAppsScript/' + file, 'utf8');
    
    // value
    content = content.replace(/document\.getElementById\('([^']+)'\)\.value\s*=\s*([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').value = $2;");
    
    // src
    content = content.replace(/document\.getElementById\('([^']+)'\)\.src\s*=\s*([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').src = $2;");

    // innerHTML
    content = content.replace(/document\.getElementById\('([^']+)'\)\.innerHTML\s*=\s*([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').innerHTML = $2;");
    
    // textContent (in case we missed any)
    content = content.replace(/document\.getElementById\('([^']+)'\)\.textContent\s*=\s*([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').textContent = $2;");

    // style.display
    content = content.replace(/document\.getElementById\('([^']+)'\)\.style\.display\s*=\s*([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').style.display = $2;");

    fs.writeFileSync('GoogleAppsScript/' + file, content);
}
console.log('Patched JS files for safe getElementById assignments.');
