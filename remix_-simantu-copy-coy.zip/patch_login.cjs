const fs = require('fs');

let html = fs.readFileSync('GoogleAppsScript/login.html', 'utf8');
html = html.replace(
`<div id="googleAccountInfo" class="text-center mb-4 d-none">`,
`<div id="vercelLoginInfo" class="mb-4">
    <label class="form-label text-muted small mb-1">Masukkan Email Anda:</label>
    <div class="input-group">
        <span class="input-group-text bg-light"><i class="fas fa-envelope text-muted"></i></span>
        <input type="email" id="inputEmail" class="form-control" placeholder="email@sekolah.id" required>
    </div>
</div>
<div id="googleAccountInfo" class="text-center mb-4 d-none">`
);
fs.writeFileSync('GoogleAppsScript/login.html', html);

let js = fs.readFileSync('GoogleAppsScript/login.js.html', 'utf8');
js = js.replace(
/google\.script\.run\s*\.withSuccessHandler\(function\(response\) \{/g,
`const inputEmail = document.getElementById('inputEmail').value;
        if (!inputEmail) {
            hideLoading();
            showAlert('Peringatan', 'Harap masukkan email Anda.', 'warning');
            return;
        }
        
        if(typeof google !== 'undefined' && google.script) {
            google.script.run
                .withSuccessHandler(function(response) {`
);

js = js.replace(/\.loginWithGoogle\(\);/g, `.loginWithGoogle(inputEmail);`);
fs.writeFileSync('GoogleAppsScript/login.js.html', js);

let auth = fs.readFileSync('GoogleAppsScript/Auth.gs', 'utf8');
auth = auth.replace(/function loginWithGoogle\(\) \{/g, `function loginWithGoogle(manualEmail) {`);
auth = auth.replace(/var email = Session\.getActiveUser\(\)\.getEmail\(\);/g, `var email = manualEmail || Session.getActiveUser().getEmail();`);
fs.writeFileSync('GoogleAppsScript/Auth.gs', auth);
