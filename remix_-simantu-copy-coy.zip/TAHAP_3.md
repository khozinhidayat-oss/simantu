# TAHAP 3: Master Data

Tahap 3 berfokus pada pembuatan antarmuka dan logika untuk pengelolaan Master Data. Sesuai spesifikasi, aplikasi akan menangani 4 entitas utama: Data Guru, Data Kelas, Data Siswa, dan Mata Pelajaran. 

## Penjelasan Singkat
Pada tahap ini, kita membuat halaman HTML untuk masing-masing Master Data menggunakan tabel Bootstrap 5 dan DataTables (disimulasikan). Guru hanya dapat melihat siswa pada kelas yang diajarnya dan mengubah profilnya sendiri, namun karena ini Master Data (umumnya dikelola oleh admin/kurikulum), dalam konteks SI-MENGAJAR (hanya untuk guru), kita akan membuat antarmuka read-only (atau sesuai permission) untuk Kelas, Siswa (view), Mapel (view), dan Guru (view profil teman sejawat/sendiri). Untuk keperluan purwarupa, ditambahkan tombol interaktif agar UI terasa hidup.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
â”œâ”€â”€ Guru.gs, Kelas.gs, Siswa.gs, Mapel.gs (Fungsi Backend CRUD dummy)
â”œâ”€â”€ guru.html, kelas.html, siswa.html, mapel.html (Tampilan UI)
â””â”€â”€ guru.js.html, kelas.js.html, siswa.js.html, mapel.js.html (Logika interaksi & render tabel)
```

Seluruh file telah dihubungkan ke struktur SPA utama (`index.html`) dan siap dijalankan.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 4 (Jadwal Mengajar)**.
