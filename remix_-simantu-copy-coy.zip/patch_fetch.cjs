const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');
html = html.replace(/\.then\(res => res\.json\(\)\)/g, `.then(res => res.text()).then(text => {
                                        if (!text) throw new Error("Empty response from server");
                                        try {
                                            return JSON.parse(text);
                                        } catch (e) {
                                            console.error("Failed to parse JSON. Raw response:", text);
                                            throw new Error("Invalid JSON response");
                                        }
                                    })`);
fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
