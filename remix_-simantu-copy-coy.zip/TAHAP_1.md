# TAHAP 1: Analisis & Perancangan SI-MENGAJAR GURU

## 1. Analisis Kebutuhan
SI-MENGAJAR GURU adalah sistem informasi administrasi mengajar khusus untuk guru, tanpa akses untuk siswa atau admin sekolah. Sistem ini bertujuan mengintegrasikan seluruh proses administrasi guru agar lebih efisien dan tidak terjadi redundansi data.

**Fitur Utama:**
- **Dashboard:** Ringkasan aktivitas, jadwal, dan notifikasi.
- **Master Data:** Pengelolaan data guru, kelas, siswa, dan mata pelajaran.
- **Administrasi:** Absensi, Modul Ajar, Jurnal Mengajar, dan Penilaian yang saling terintegrasi.
- **Laporan & Profil:** Rekapitulasi data yang dapat difilter dan diekspor, serta pengaturan profil pengguna.

## 2. Struktur Folder (Google Apps Script)
Sesuai dengan arsitektur MVC dan best practice GAS, kode akan dipisah menjadi beberapa file:
```text
/SI-MENGAJAR-GURU
âââ Backend (.gs)
â   âââ Code.gs (Entry point, doGet)
â   âââ Config.gs (Konfigurasi URL, ID Spreadsheet)
â   âââ Auth.gs (Otentikasi & Sesi)
â   âââ Dashboard.gs, Guru.gs, Siswa.gs, Kelas.gs, Mapel.gs, Jadwal.gs, Absensi.gs, Modul.gs, Jurnal.gs, Penilaian.gs, Report.gs
â   âââ Spreadsheet.gs (Fungsi CRUD ke Spreadsheet)
â   âââ Utils.gs, Helper.gs
âââ Frontend (HTML/JS/CSS)
â   âââ index.html
â   âââ navbar.html, sidebar.html, footer.html, loading.html
â   âââ dashboard.html, guru.html, kelas.html, siswa.html, mapel.html, jadwal.html, absensi.html, modul.html, jurnal.html, penilaian.html, laporan.html, profil.html
â   âââ javascript (.html dengan tag <script>): utils.js.html, dashboard.js.html, dll.
â   âââ css (.html dengan tag <style>): style.css.html, theme.css.html, component.css.html
```

## 3. Struktur Database (Google Spreadsheet)
Setiap Sheet akan memiliki kolom standar: `ID, CreatedAt, UpdatedAt, CreatedBy, UpdatedBy, Status`.

- **User**: ID, Email, Password, Nama, Role (Guru), Status
- **Guru**: ID, NIP, Nama, Foto, JK, TempatLahir, TglLahir, Email, NoHP, Alamat, Status
- **Kelas**: ID, KodeKelas, NamaKelas, Jurusan, Tingkat, JmlSiswa, TahunAjaran, Semester, Status
- **Siswa**: ID, NIS, NISN, Nama, JK, TempatLahir, TglLahir, KelasID, Foto, Status
- **Mapel**: ID, KodeMapel, NamaMapel, Fase, Semester, KKM, AlokasiJam, Status
- **Jadwal**: ID, GuruID, MapelID, KelasID, Hari, JamMulai, JamSelesai, JamKe, Ruangan, Semester, TahunAjaran, Status
- **Absensi**: ID, JadwalID, Tanggal, SiswaID, StatusKehadiran (Hadir/Izin/Sakit/Alpha/Terlambat), Catatan, Status
- **ModulAjar**: ID, GuruID, MapelID, KodeModul, NamaModul, Semester, Fase, CP, TP, ATP, Materi, Metode, Media, Model, Pendekatan, Asesmen, AlokasiWaktu, Lampiran, Status
- **Jurnal**: ID, JadwalID, ModulID, Tanggal, Pertemuan, Materi, Aktivitas, Refleksi, Hambatan, Solusi, Catatan, FotoDokumentasi, Status
- **Nilai**: ID, JadwalID, SiswaID, JenisPenilaian, Nilai, Predikat, Deskripsi, Status
- **LogAktivitas**: ID, GuruID, Aktivitas, Waktu
- **Pengaturan**: ID, Kunci, Nilai

## 4. ERD (Entity Relationship Diagram)
```mermaid
erDiagram
    GURU ||--o{ JADWAL : "mengajar"
    GURU ||--o{ MODUL_AJAR : "membuat"
    KELAS ||--o{ SISWA : "memiliki"
    MAPEL ||--o{ JADWAL : "diampu pada"
    KELAS ||--o{ JADWAL : "memiliki"
    JADWAL ||--o{ ABSENSI : "mencatat"
    JADWAL ||--o{ JURNAL : "memiliki"
    JADWAL ||--o{ NILAI : "menghasilkan"
    MODUL_AJAR ||--o{ JURNAL : "digunakan di"
    SISWA ||--o{ ABSENSI : "kehadiran"
    SISWA ||--o{ NILAI : "mendapatkan"
```

## 5. Flowchart (Alur Utama Aplikasi)
```mermaid
graph TD
    A[Login] --> B{Validasi}
    B -- Gagal --> A
    B -- Sukses --> C[Dashboard]
    C --> D[Master Data]
    C --> E[Administrasi Mengajar]
    C --> F[Laporan & Profil]
    
    E --> E1[Jadwal Mengajar]
    E1 --> E2[Absensi Siswa]
    E1 --> E3[Jurnal Mengajar]
    E1 --> E4[Penilaian]
    
    E3 -->|Tarik Data| E5[Modul Ajar]
```

## 6. Wireframe
Wireframe Dashboard telah diimplementasikan secara interaktif di panel preview (menggunakan React & Tailwind CSS sebagai representasi UI yang akan dibangun nantinya di GAS).
