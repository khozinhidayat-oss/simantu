const fs = require('fs');

const filesToPatch = [
  {
    file: 'GoogleAppsScript/Guru.gs',
    getRegex: /function getGuruData\(\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getGuruData() {
  try {
    var data = getTableData('Guru');
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveGuru\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveGuru(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('Guru', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('Guru', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  },
  {
    file: 'GoogleAppsScript/Siswa.gs',
    getRegex: /function getSiswaData\(\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getSiswaData() {
  try {
    var data = getTableData('Siswa');
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveSiswa\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveSiswa(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('Siswa', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('Siswa', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  },
  {
    file: 'GoogleAppsScript/Kelas.gs',
    getRegex: /function getKelasData\(\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getKelasData() {
  try {
    var data = getTableData('Kelas');
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveKelas\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveKelas(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('Kelas', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('Kelas', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  },
  {
    file: 'GoogleAppsScript/Mapel.gs',
    getRegex: /function getMapelData\(\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getMapelData() {
  try {
    var data = getTableData('Mapel');
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveMapel\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveMapel(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('Mapel', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('Mapel', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  },
  {
    file: 'GoogleAppsScript/Jadwal.gs',
    getRegex: /function getJadwalData\(userEmail\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getJadwalData(userEmail) {
  try {
    var data = getTableData('Jadwal');
    if(userEmail) {
      var user = Session.getActiveUser().getEmail();
      var guruData = getTableData('User');
      var userObj = guruData.find(function(g) { return g.Username === user; });
      if(userObj && userObj.KodeGuru) {
        data = data.filter(function(d) { return d.KodeGuru === userObj.KodeGuru; });
      }
    }
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveJadwal\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveJadwal(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('Jadwal', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('Jadwal', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  },
  {
    file: 'GoogleAppsScript/Jurnal.gs',
    getRegex: /function getJurnalData\(userEmail\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getJurnalData(userEmail) {
  try {
    var data = getTableData('Jurnal');
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveJurnal\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveJurnal(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('Jurnal', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('Jurnal', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  },
  {
    file: 'GoogleAppsScript/Modul.gs',
    getRegex: /function getModulData\(userEmail\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    getRepl: `function getModulData(userEmail) {
  try {
    var data = getTableData('ModulAjar');
    return { success: true, data: data };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`,
    saveRegex: /function saveModul\(payload\) \{[\s\S]*?return \{ success: false, message: e\.toString\(\) \};\s*\}/,
    saveRepl: `function saveModul(payload) {
  try {
    if (payload.ID) {
      return updateTableRow('ModulAjar', 'ID', payload.ID, payload);
    } else {
      return insertTableRow('ModulAjar', payload);
    }
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`
  }
];

filesToPatch.forEach(fp => {
  let content = fs.readFileSync(fp.file, 'utf8');
  content = content.replace(fp.getRegex, fp.getRepl);
  content = content.replace(fp.saveRegex, fp.saveRepl);
  fs.writeFileSync(fp.file, content);
});
