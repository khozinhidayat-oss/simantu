const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/index.html', 'utf8');

function includeFile(filename) {
    const paths = [
        `GoogleAppsScript/${filename}.html`,
        `GoogleAppsScript/${filename}.css.html`,
        `GoogleAppsScript/${filename}.js.html`
    ];
    
    for (let p of paths) {
        if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8');
    }
    return '';
}

let lastHtml = '';
while(html !== lastHtml) {
    lastHtml = html;
    html = html.replace(/<\?!=?\s*include\(['"]([^'"]+)['"]\);?\s*\?>/g, (match, p1) => {
        return includeFile(p1);
    });
}

fs.writeFileSync('index.html', html);
console.log('GAS Preview compiled to index.html');
