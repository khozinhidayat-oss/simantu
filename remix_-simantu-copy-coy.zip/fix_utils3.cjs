const fs = require('fs');
let text = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');
const idx = text.indexOf('function logout() {');
if(idx !== -1) {
    text = text.substring(0, idx) + `function logout() {
        Swal.fire({
            title: 'Keluar Sistem',
            text: 'Apakah Anda yakin ingin mengakhiri sesi ini?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya, Keluar',
            cancelButtonText: 'Batal',
            confirmButtonColor: '#dc3545',
            customClass: {
                popup: 'rounded-4 border-0 shadow-sm'
            }
        }).then((result) => {
            if(result.isConfirmed) {
                var sessionId = localStorage.getItem('simengajar_session_id');
                if(typeof google !== 'undefined' && google.script && sessionId) {
                    showLoading('Memproses logout...');
                    google.script.run
                        .withSuccessHandler(function(res) {
                            hideLoading();
                            localStorage.removeItem('simengajar_session_id');
                            currentUser = null;
                            document.getElementById('app').innerHTML = '<?!= include("login"); ?>';
                            if (typeof initLogin === 'function') initLogin();
                            showAlert('Berhasil', 'Anda berhasil logout.', 'success');
                        })
                        .withFailureHandler(function(err) {
                            hideLoading();
                            showAlert('Error', 'Gagal memproses logout: ' + err.message, 'error');
                        })
                        .logout(sessionId);
                } else {
                    localStorage.removeItem('simengajar_session_id');
                    currentUser = null;
                    document.getElementById('app').innerHTML = '<?!= include("login"); ?>';
                    if (typeof initLogin === 'function') initLogin();
                    showAlert('Berhasil', 'Anda berhasil logout.', 'success');
                }
            }
        });
    }
</script>`;
    fs.writeFileSync('GoogleAppsScript/utils.js.html', text);
}
