# TAHAP 4: Jadwal Mengajar

Tahap 4 berfokus pada pembuatan fitur Jadwal Mengajar, di mana guru dapat melihat jadwal mengajarnya sendiri dalam berbagai format (Tabel dan Timeline/Calendar).

## Penjelasan Singkat
Pada tahap ini, kita membuat halaman `jadwal.html` yang memanfaatkan sistem tab (Bootstrap Nav-Tabs) untuk beralih antara tampilan Tabel yang detail dan tampilan Timeline yang intuitif. Terdapat logika untuk mendeteksi **Hari Ini** secara otomatis: jadwal pada hari ini akan diberi penanda khusus (highlight warna biru) dan menampilkan tombol aksi "Isi Absensi" untuk memudahkan alur kerja guru (terintegrasi ke tahap selanjutnya).

## Struktur File yang Dibuat

```text
/GoogleAppsScript
â”œâ”€â”€ Jadwal.gs (Fungsi Backend dummy untuk mengambil jadwal guru)
â”œâ”€â”€ jadwal.html (Tampilan UI: Table dan Timeline dengan filter)
â””â”€â”€ jadwal.js.html (Logika frontend untuk render data sesuai view dan mendeteksi hari aktif)
```

File telah diintegrasikan dengan kerangka SPA pada `index.html` dan `utils.js.html`. Setelah file dibuat, perintah `node build-gas.cjs` dijalankan untuk menyusun `index.html` utuh yang siap direview.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 5 (Absensi Siswa)**.
