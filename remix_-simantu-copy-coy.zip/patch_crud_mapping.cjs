const fs = require('fs');

const mappings = {
  Guru: {
    get: `
    var data = getTableData('Guru').map(function(d) {
      return { id: d.ID, kode: d.KodeGuru, nama: d.NamaGuru, nip: d.NIP, nohp: d.NoHP, email: d.Email, status: d.Status, jk: d.JenisKelamin || 'L' };
    });
`,
    save: `
    var record = { ID: payload.id, KodeGuru: payload.kode || ('G'+Math.floor(Math.random()*1000)), NamaGuru: payload.nama, NIP: payload.nip, NoHP: payload.nohp, Email: payload.email, Status: payload.status, JenisKelamin: payload.jk };
    if (payload.id) {
      return updateTableRow('Guru', 'ID', payload.id, record);
    } else {
      return insertTableRow('Guru', record);
    }
`
  },
  Siswa: {
    get: `
    var data = getTableData('Siswa').map(function(d) {
      return { id: d.ID, nis: d.NIS, nisn: d.NISN, nama: d.NamaSiswa, jk: d.JenisKelamin, kelas: d.KodeKelas, status: d.Status };
    });
`,
    save: `
    var record = { ID: payload.id, NIS: payload.nis, NISN: payload.nisn, NamaSiswa: payload.nama, JenisKelamin: payload.jk, KodeKelas: payload.kelas, Status: payload.status };
    if (payload.id) {
      return updateTableRow('Siswa', 'ID', payload.id, record);
    } else {
      return insertTableRow('Siswa', record);
    }
`
  },
  Kelas: {
    get: `
    var data = getTableData('Kelas').map(function(d) {
      return { id: d.ID, kode: d.KodeKelas, nama: d.NamaKelas, wali: d.WaliKelas, kapasitas: d.Kapasitas };
    });
`,
    save: `
    var record = { ID: payload.id, KodeKelas: payload.kode || payload.nama, NamaKelas: payload.nama, WaliKelas: payload.wali, Kapasitas: payload.kapasitas };
    if (payload.id) {
      return updateTableRow('Kelas', 'ID', payload.id, record);
    } else {
      return insertTableRow('Kelas', record);
    }
`
  },
  Mapel: {
    get: `
    var data = getTableData('Mapel').map(function(d) {
      return { id: d.ID, kode: d.KodeMapel, nama: d.NamaMapel, kkm: d.KKM, tingkat: d.Tingkat };
    });
`,
    save: `
    var record = { ID: payload.id, KodeMapel: payload.kode || payload.nama, NamaMapel: payload.nama, KKM: payload.kkm, Tingkat: payload.tingkat };
    if (payload.id) {
      return updateTableRow('Mapel', 'ID', payload.id, record);
    } else {
      return insertTableRow('Mapel', record);
    }
`
  },
  Jadwal: {
    get: `
    var data = getTableData('Jadwal');
    var kelas = getTableData('Kelas');
    var mapel = getTableData('Mapel');
    
    if(userEmail) {
      var user = Session.getActiveUser().getEmail();
      var guruData = getTableData('User');
      var userObj = guruData.find(function(g) { return g.Username === user; });
      if(userObj && userObj.KodeGuru) {
        data = data.filter(function(d) { return d.KodeGuru === userObj.KodeGuru; });
      }
    }
    data = data.map(function(d) {
      var k = kelas.find(function(c) { return c.KodeKelas === d.KodeKelas; });
      var m = mapel.find(function(m) { return m.KodeMapel === d.KodeMapel; });
      return {
        id: d.ID,
        hari: d.Hari,
        jamMulai: d.JamMulai,
        jamSelesai: d.JamSelesai,
        mapel: d.KodeMapel,
        namaMapel: m ? m.NamaMapel : d.KodeMapel,
        kelas: d.KodeKelas,
        namaKelas: k ? k.NamaKelas : d.KodeKelas
      };
    });
`,
    save: `
    var record = { ID: payload.id, Hari: payload.hari, JamMulai: payload.jamMulai, JamSelesai: payload.jamSelesai, KodeMapel: payload.mapel, KodeKelas: payload.kelas };
    if (payload.id) {
      return updateTableRow('Jadwal', 'ID', payload.id, record);
    } else {
      return insertTableRow('Jadwal', record);
    }
`
  },
  Modul: {
    get: `
    var data = getTableData('ModulAjar').map(function(d) {
      return { id: d.ID, kode: d.KodeMapel, nama: d.JudulModul, materi: d.Materi, status: d.Status, lampiran: d.LinkFile };
    });
`,
    save: `
    var record = { ID: payload.id, KodeMapel: payload.kode, JudulModul: payload.nama, Materi: payload.materi, Status: payload.status, LinkFile: payload.lampiran };
    if (payload.id) {
      return updateTableRow('ModulAjar', 'ID', payload.id, record);
    } else {
      return insertTableRow('ModulAjar', record);
    }
`
  },
  Jurnal: {
    get: `
    var data = getTableData('Jurnal');
    var jadwal = getTableData('Jadwal');
    var kelas = getTableData('Kelas');
    var mapel = getTableData('Mapel');
    
    data = data.map(function(d) {
      var j = jadwal.find(function(jd) { return jd.ID === d.KodeJadwal; });
      var kName = j ? j.KodeKelas : '';
      var mName = j ? j.KodeMapel : '';
      if(j) {
         var k = kelas.find(function(c) { return c.KodeKelas === j.KodeKelas; });
         if(k) kName = k.NamaKelas;
         var m = mapel.find(function(c) { return c.KodeMapel === j.KodeMapel; });
         if(m) mName = m.NamaMapel;
      }
      return { id: d.ID, tanggal: d.Tanggal, jadwalId: d.KodeJadwal, kelas: kName, mapel: mName, materi: d.MateriPokok, aktivitas: d.Kegiatan, kendala: d.Catatan };
    });
`,
    save: `
    var record = { ID: payload.id, Tanggal: payload.tanggal, KodeJadwal: payload.jadwalId, MateriPokok: payload.materi, Kegiatan: payload.aktivitas, Catatan: payload.kendala };
    if (payload.id) {
      return updateTableRow('Jurnal', 'ID', payload.id, record);
    } else {
      return insertTableRow('Jurnal', record);
    }
`
  }
};

for (const [key, map] of Object.entries(mappings)) {
  const file = `GoogleAppsScript/${key}.gs`;
  let content = fs.readFileSync(file, 'utf8');
  
  // replace get block
  content = content.replace(/var data = getTableData\('[^']+'\);[\\s\\S]*?(?=return \{ success: true)/, map.get);
  
  // replace save block
  content = content.replace(/if \(payload\.ID\) \{[\s\S]*?return insertTableRow\('[^']+', payload\);\s*\}/, map.save);
  
  fs.writeFileSync(file, content);
}
