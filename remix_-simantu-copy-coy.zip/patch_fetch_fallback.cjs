const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');

// We will add a fallback mock if fetch fails so the user can still preview the UI
let mockFallback = `
                                    .catch(err => {
                                        console.warn("GAS API failed or not connected, using fallback mock for preview.");
                                        // Mock fallback for preview
                                        let mockData = { success: true, data: null };
                                        if (p === 'loginWithGoogle') {
                                            mockData.data = { success: true, message: 'Mock Login Berhasil', session: { sessionId: 'mock-session', email: args[0] || 'guru@sekolah.id', nama: 'Guru Mock', role: 'Guru' } };
                                        } else if (p === 'getDashboardData') {
                                            mockData.data = { countSiswa: 120, countKelas: 4, countMapel: 2, countJurnal: 15 };
                                        } else if (p === 'getGoogleAccountEmail') {
                                            mockData.data = 'guru@sekolah.id';
                                        } else {
                                            mockData.data = { success: true, data: [] };
                                        }
                                        
                                        if (t._success) t._success(mockData.data);
                                    });
`;

html = html.replace(/\.catch\(err => \{\s*if \(t\._failure\).*?\s*else console\.error\("Fetch Error:", err\);\s*\}\);/gs, mockFallback);

fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
