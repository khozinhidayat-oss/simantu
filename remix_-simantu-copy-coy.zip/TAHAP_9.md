# TAHAP 9: Rekap Laporan & Cetak

Tahap 9 berfokus pada fitur pembuatan laporan akhir yang merangkum kinerja akademik (Absensi, Jurnal, Nilai) bagi siswa dalam satu dashboard terpadu. Fitur ini sangat berguna bagi guru saat menghadapi masa pembagian rapor atau rapat evaluasi.

## Penjelasan Singkat
Pada halaman Rekap Laporan, guru dapat memfilter laporan berdasarkan Kelas, Mata Pelajaran, dan rentang waktu (Tanggal Awal dan Akhir). Saat tombol "Buat Laporan" diklik, sistem akan menampilkan statistik ringkas (Total Pertemuan, Rata-rata Kehadiran, Rata-rata Nilai) beserta rincian tabel siswa. Disediakan pula tombol "Cetak PDF" dan "Export Excel" yang akan memunculkan alert (sebagai simulasi) bahwa fitur cetak dokumen ini sedang diproses.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
├── Laporan.gs (Fungsi Backend dummy untuk mengkalkulasi rekap laporan)
├── laporan.html (Tampilan UI: Form filter laporan, kartu statistik, dan tabel rincian)
└── laporan.js.html (Logika frontend untuk render laporan dan interaksi tombol export)
```

File telah diintegrasikan dengan kerangka SPA pada `index.html` dan `utils.js.html`. Setelah file dibuat, perintah `node build-gas.cjs` dijalankan untuk menyusun `index.html` utuh yang siap direview.

Silakan beri perintah **"lanjut"** untuk menyelesaikan proses atau melakukan pengujian akhir.
