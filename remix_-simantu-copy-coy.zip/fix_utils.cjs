const fs = require('fs');

let html = `
<script>
    // --- MOCK google.script.run FOR VERCEL ---
    if (typeof window.google === 'undefined') {
        window.google = {};
    }
    if (typeof window.google.script === 'undefined') {
        const GAS_API_URL = localStorage.getItem('GAS_API_URL') || prompt('Masukkan URL Google Apps Script Web App (API):') || '';
        if (GAS_API_URL) localStorage.setItem('GAS_API_URL', GAS_API_URL);
        
        window.google.script = {
            run: new Proxy({}, {
                get: function(target, prop) {
                    if (prop === 'withSuccessHandler' || prop === 'withFailureHandler') {
                        const builder = { _success: null, _failure: null };
                        const createProxy = (b) => new Proxy(b, {
                            get: function(t, p) {
                                if (p === 'withSuccessHandler') {
                                    return (cb) => { t._success = cb; return createProxy(t); };
                                }
                                if (p === 'withFailureHandler') {
                                    return (cb) => { t._failure = cb; return createProxy(t); };
                                }
                                return function(...args) {
                                    let promise;
                                    if (!GAS_API_URL) {
                                        promise = Promise.reject(new Error("No GAS_API_URL"));
                                    } else {
                                        promise = fetch(GAS_API_URL, {
                                            method: 'POST',
                                            redirect: 'follow',
                                            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                                            body: JSON.stringify({ method: p, args: args })
                                        }).then(res => res.text()).then(text => {
                                            if (!text) throw new Error("Respons kosong. Ini sering terjadi karena masalah CORS jika Web App di-deploy sebagai 'User accessing the web app'. Untuk Vercel, deploy harus sebagai 'Execute as: Me' dengan akses 'Anyone'.");
                                            try {
                                                return JSON.parse(text);
                                            } catch (e) {
                                                console.error("Failed to parse JSON. Raw response:", text);
                                                throw new Error("Invalid JSON response");
                                            }
                                        });
                                    }
                                    
                                    promise.then(data => {
                                        if (data.success) {
                                            if (t._success) t._success(data.data);
                                        } else {
                                            if (t._failure) t._failure(new Error(data.error));
                                            else console.error("GAS Error:", data.error);
                                        }
                                    }).catch(err => {
                                        console.warn("GAS API failed or not connected, using fallback mock for preview.");
                                        let mockData = { success: true, data: null };
                                        if (p === 'loginWithGoogle') {
                                            mockData.data = { success: true, message: 'Mock Login Berhasil', session: { sessionId: 'mock-session', email: args[0] || 'guru@sekolah.id', nama: 'Guru Mock', role: 'Guru' } };
                                        } else if (p === 'getDashboardData') {
                                            mockData.data = { countSiswa: 120, countKelas: 4, countMapel: 2, countJurnal: 15 };
                                        } else if (p === 'getGoogleAccountEmail') {
                                            mockData.data = 'guru@sekolah.id';
                                        } else {
                                            mockData.data = { success: true, data: [] };
                                        }
                                        if (t._success) t._success(mockData.data);
                                    });
                                };
                            }
                        });
                        return createProxy(builder)[prop];
                    }
                    
                    return function(...args) {
                        if (!GAS_API_URL) {
                            console.warn("No GAS_API_URL for", prop);
                            return;
                        }
                        fetch(GAS_API_URL, {
                            method: 'POST',
                            redirect: 'follow',
                            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                            body: JSON.stringify({ method: prop, args: args })
                        })
                        .then(res => res.text())
                        .then(text => {
                            if (!text) throw new Error("Empty response");
                            return JSON.parse(text);
                        })
                        .then(data => {
                            if (!data.success) console.error("GAS Error:", data.error);
                        })
                        .catch(err => console.error("Fetch Error:", err));
                    };
                }
            })
        };
    }
    // --- END MOCK ---
`;

let origHtml = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');
let restOfHtml = origHtml.substring(origHtml.indexOf('// Theme Management'));
fs.writeFileSync('GoogleAppsScript/utils.js.html', html + '\n    ' + restOfHtml);

