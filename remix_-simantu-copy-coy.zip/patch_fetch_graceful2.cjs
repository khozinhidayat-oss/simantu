const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');

html = html.replace(/if \(\!GAS_API_URL\) \{[\s\S]*?throw new Error\("GAS_API_URL missing"\);\s*\}/g, `
`);

// wrap fetch in a promise if GAS_API_URL exists, otherwise reject
html = html.replace(/fetch\(GAS_API_URL, \{/g, `(GAS_API_URL ? fetch(GAS_API_URL, {`);
html = html.replace(/\}\)\s*\.then/g, `}) : Promise.reject(new Error("No GAS_API_URL"))).then`);

fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
