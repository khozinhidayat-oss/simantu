# TAHAP 7: Jurnal Mengajar

Tahap 7 berfokus pada fitur pengisian dan rekap Jurnal Mengajar oleh guru. Fitur ini memungkinkan guru mendokumentasikan setiap sesi pembelajaran, termasuk materi, aktivitas, kendala, dan tindak lanjut.

## Penjelasan Singkat
Halaman Jurnal Mengajar menyediakan sebuah formulir (Modal) bagi guru untuk mengisi jurnal harian dengan menginput Tanggal, Kelas, Mata Pelajaran, Jam Ke, Materi Bahasan, Aktivitas, Kendala, serta Tindak Lanjut. Selain itu, terdapat tabel rekapitulasi jurnal yang telah diisi, lengkap dengan fungsi pencarian dan filter berdasarkan bulan/tanggal. Data disimulasikan menggunakan interaksi JavaScript.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
├── Jurnal.gs (Fungsi Backend dummy untuk mengambil dan menyimpan jurnal)
├── jurnal.html (Tampilan UI: Tabel riwayat jurnal & Modal form isi jurnal)
└── jurnal.js.html (Logika frontend untuk render, simpan, hapus, filter jurnal)
```

File telah diintegrasikan dengan kerangka SPA pada `index.html` dan `utils.js.html`. Setelah file dibuat, perintah `node build-gas.cjs` dijalankan untuk menyusun `index.html` utuh yang siap direview.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 8 (Penilaian)**.
