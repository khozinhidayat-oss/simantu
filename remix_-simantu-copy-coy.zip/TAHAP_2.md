# TAHAP 2: Login & Dashboard

Tahap 2 berfokus pada pembuatan struktur utama file Google Apps Script, sistem otentikasi (Login), dan halaman Dashboard yang dinamis. 

## Penjelasan Singkat
Pada tahap ini, kita menerapkan pola **Single Page Application (SPA)** di Google Apps Script. Server (`Code.gs`) hanya akan memuat halaman `index.html` satu kali. Navigasi antar halaman (seperti ke halaman Dashboard) akan ditangani oleh JavaScript (`utils.js.html`) dengan memanipulasi DOM. Semua styling menggunakan Bootstrap 5 dan Chart.js untuk visualisasi data aktivitas mengajar.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
â”œâ”€â”€ Code.gs (Entry point & Web App setup)
â”œâ”€â”€ Config.gs (Konfigurasi Global & Spreadsheet ID)
â”œâ”€â”€ Auth.gs (Fungsi Backend untuk verifikasi login)
â”œâ”€â”€ Dashboard.gs (Fungsi Backend untuk mengambil data rekap)
â”œâ”€â”€ Spreadsheet.gs (Helper fungsi untuk membaca sheet)
â”œâ”€â”€ Utils.gs (Fungsi-fungsi utilitas backend)
â”œâ”€â”€ index.html (Kerangka utama aplikasi / Layout Dasar)
â”œâ”€â”€ login.html (Tampilan form login)
â”œâ”€â”€ dashboard.html (Tampilan dashboard)
â”œâ”€â”€ navbar.html (Tampilan header/navbar)
â”œâ”€â”€ sidebar.html (Tampilan menu samping)
â”œâ”€â”€ footer.html (Tampilan footer)
â”œâ”€â”€ loading.html (Komponen loading spinner)
â”œâ”€â”€ style.css.html (File CSS Kustom)
â”œâ”€â”€ utils.js.html (Logic frontend untuk navigasi & alert)
â”œâ”€â”€ login.js.html (Logic form login)
â””â”€â”€ dashboard.js.html (Logic fetching & render chart dashboard)
```

Seluruh file telah disesuaikan agar bisa langsung disalin-tempel ke Google Apps Script Editor. Pada lingkungan lokal/preview AI Studio ini, terdapat fungsi *fallback* pada Javascript agar antarmuka (UI) tetap bisa diklik dan diuji coba meskipun tidak tersambung langsung ke Google Script API.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 3 (Master Data)**.
