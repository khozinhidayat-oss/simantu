const fs = require('fs');
let content = fs.readFileSync('GoogleAppsScript/pengaturan.js.html', 'utf8');

// For textContent
content = content.replace(/const el_([a-zA-Z0-9\-_]+) = document\.getElementById\('\1'\); if\(el_\1\) el_\1\.textContent = ([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').textContent = $2;");

// For innerText
content = content.replace(/const el_([a-zA-Z0-9\-_]+) = document\.getElementById\('\1'\); if\(el_\1\) el_\1\.innerText = ([^;]+);/g, "if(document.getElementById('$1')) document.getElementById('$1').innerText = $2;");

fs.writeFileSync('GoogleAppsScript/pengaturan.js.html', content);
