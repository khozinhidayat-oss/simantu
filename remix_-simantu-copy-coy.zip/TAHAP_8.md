# TAHAP 8: Penilaian

Tahap 8 berfokus pada fitur Penilaian (Input Nilai) bagi siswa. Guru dapat memasukkan nilai siswa berdasarkan kelas, mata pelajaran, dan jenis penilaian yang dipilih.

## Penjelasan Singkat
Pada halaman Penilaian, guru dihadapkan pada form filter untuk memilih Kelas, Mata Pelajaran, dan Jenis Penilaian (misalnya Formatif, Sumatif, PTS, PAS). Setelah form tersebut diisi dan tombol "Tampilkan Siswa" diklik, tabel daftar siswa akan muncul beserta kolom input nilai. Sistem memiliki logika validasi sederhana di mana nilai yang berada di bawah KKM (Kriteria Ketuntasan Minimal, misalnya 75) akan diwarnai merah. Setelah nilai diinput, data dapat disimpan.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
├── Penilaian.gs (Fungsi Backend dummy untuk mengambil daftar siswa, nilai, & simpan nilai)
├── penilaian.html (Tampilan UI: Form filter & Tabel input nilai dinamis)
└── penilaian.js.html (Logika frontend untuk kalkulasi warna KKM & handle penyimpanan)
```

File telah diintegrasikan dengan kerangka SPA pada `index.html` dan `utils.js.html`. Setelah file dibuat, perintah `node build-gas.cjs` dijalankan untuk menyusun `index.html` utuh yang siap direview.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 9 (Laporan & Cetak)**.
