const fs = require('fs');

const files = [
  { f: 'GoogleAppsScript/Guru.gs', t: 'Guru' },
  { f: 'GoogleAppsScript/Siswa.gs', t: 'Siswa' },
  { f: 'GoogleAppsScript/Kelas.gs', t: 'Kelas' },
  { f: 'GoogleAppsScript/Mapel.gs', t: 'Mapel' },
  { f: 'GoogleAppsScript/Jadwal.gs', t: 'Jadwal' },
  { f: 'GoogleAppsScript/Modul.gs', t: 'ModulAjar' },
  { f: 'GoogleAppsScript/Jurnal.gs', t: 'Jurnal' }
];

files.forEach(obj => {
  let content = fs.readFileSync(obj.f, 'utf8');
  let regex = new RegExp(`function delete${obj.t === 'ModulAjar' ? 'Modul' : obj.t}\\(id\\) \\{[\\s\\S]*?return \\{ success: false, message: e\\.toString\\(\\) \\};\\s*\\}`);
  let repl = `function delete${obj.t === 'ModulAjar' ? 'Modul' : obj.t}(id) {
  try {
    return deleteTableRow('${obj.t}', 'ID', id);
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}`;
  content = content.replace(regex, repl);
  
  // also fix the extra curly brace that might be present due to previous bad replace
  content = content.replace(/\}\n\}/g, '}');
  
  fs.writeFileSync(obj.f, content);
});
