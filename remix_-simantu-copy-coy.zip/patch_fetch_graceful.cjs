const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');

html = html.replace(/if \(\!GAS_API_URL\) \{[\s\S]*?throw new Error.*?;\s*\}/g, `if (!GAS_API_URL) {
    console.warn("GAS_API_URL is missing, using mock.");
    // Force throw to trigger catch block for mock
    throw new Error("GAS_API_URL missing");
}`);

fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
