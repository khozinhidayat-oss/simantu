const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const scriptRegex = /<script>([\s\S]*?)<\/script>/g;
let match;
let count = 0;
while ((match = scriptRegex.exec(html)) !== null) {
  const code = match[1];
  try {
    new Function(code);
  } catch (e) {
    console.log("Error in script " + count + ": " + e.message);
    console.log(code.substring(0, 200));
  }
  count++;
}
