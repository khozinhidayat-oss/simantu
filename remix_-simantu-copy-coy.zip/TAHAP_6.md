# TAHAP 6: Modul Ajar

Tahap 6 berfokus pada fitur pengelolaan Modul Ajar oleh guru. Guru dapat merancang, menambahkan, mengedit, menghapus, serta melihat modul ajar yang akan digunakan dalam pembelajaran.

## Penjelasan Singkat
Pada halaman Modul Ajar, ditampilkan tabel daftar modul ajar yang telah dibuat oleh guru. Terdapat tombol "Tambah Modul" yang akan memunculkan sebuah modal dengan form input komprehensif (mulai dari Kode, Nama Modul, CP, TP, ATP, Metode, Media, Asesmen, dsb). Simulasi pengunggahan dokumen PDF juga ditambahkan untuk mengakomodasi kolom Lampiran. Semua aksi dasar CRUD (Create, Read, Update, Delete) disimulasikan menggunakan interaksi JavaScript dan SweetAlert2.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
├── Modul.gs (Fungsi Backend dummy untuk CRUD Modul Ajar)
├── modul.html (Tampilan UI: Tabel daftar modul & Modal Form)
└── modul.js.html (Logika frontend untuk load, tambah, edit, hapus, dan validasi form)
```

File telah diintegrasikan dengan kerangka SPA pada `index.html` dan `utils.js.html`. Setelah file dibuat, perintah `node build-gas.cjs` dijalankan untuk menyusun `index.html` utuh yang siap direview.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 7 (Jurnal Mengajar)**.
