# TAHAP 5: Absensi Siswa

Tahap 5 berfokus pada pembuatan fitur Absensi Siswa. Fitur ini dirancang agar terintegrasi langsung dengan Jadwal Mengajar, sehingga guru tidak perlu mengetik ulang data kelas, mata pelajaran, maupun pertemuan.

## Penjelasan Singkat
Pada halaman Absensi, guru pertama-tama memilih Jadwal Mengajar hari ini. Setelah jadwal dipilih, sistem secara otomatis akan menarik data siswa untuk kelas tersebut. Guru dapat dengan mudah mengisi status kehadiran (Hadir, Izin, Sakit, Alpha, Terlambat) menggunakan tombol radio (Radio Button) yang dirancang intuitif dan memberikan catatan tambahan jika diperlukan. Setelah selesai, data dapat disimpan.

## Struktur File yang Dibuat

```text
/GoogleAppsScript
├── Absensi.gs (Fungsi Backend dummy untuk mengambil jadwal & daftar siswa serta menyimpan absensi)
├── absensi.html (Tampilan UI: Form pilih jadwal, informasi kelas, dan tabel input absensi)
└── absensi.js.html (Logika frontend untuk load siswa dinamis dan handle submit data)
```

File telah diintegrasikan dengan kerangka SPA pada `index.html` dan `utils.js.html`. Setelah file dibuat, perintah `node build-gas.cjs` dijalankan untuk menyusun `index.html` utuh yang siap direview.

Silakan beri perintah **"lanjut"** untuk melanjutkan ke **Tahap 6 (Modul Ajar)**.
