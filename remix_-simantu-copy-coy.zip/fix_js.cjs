const fs = require('fs');
let content = fs.readFileSync('GoogleAppsScript/pengaturan.js.html', 'utf8');

// The bad replacements were:
// if (document.getElementById('lbl-acc-email')) const el_lbl-acc-email = document.getElementById('lbl-acc-email'); if(el_lbl-acc-email) el_lbl-acc-email.textContent = info.account.email;
// We can find any `const el_X-Y = ...` and fix them to `if(document.getElementById('X-Y')) document.getElementById('X-Y').textContent = ...`

// Let's just create a function to set text content safely
const safeSetText = `
    function safeSetText(id, text) {
        const el = document.getElementById(id);
        if(el) el.textContent = text;
    }
`;

// wait, let's just do a manual regex replace back to the original or safe form
content = content.replace(/if\s*\(document\.getElementById\('[^']+'\)\)\s*const\s+el_[^\s=]+\s*=\s*document\.getElementById\('[^']+'\);\s*if\(el_[^\)]+\)\s*el_[^\.]+\.textContent\s*=\s*([^;]+);/g, (match, p1) => {
    // wait this regex is complex, let me just match the exact lines
    return "";
});
