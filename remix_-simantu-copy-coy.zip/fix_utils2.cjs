const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');
html = html.replace(/\}\) : Promise\.reject\(new Error\("No GAS_API_URL"\)\)\)\.then/g, "}).then");
fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
