const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');
html = html.replace(/if \(\!text\) throw new Error\("Empty response from server"\);/, 
`if (!text) throw new Error("Respons kosong. Ini sering terjadi karena masalah CORS jika Web App di-deploy sebagai 'User accessing the web app'. Untuk Vercel, deploy harus sebagai 'Execute as: Me' dengan akses 'Anyone'.");`);
fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
