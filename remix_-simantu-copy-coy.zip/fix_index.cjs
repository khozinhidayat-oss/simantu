const fs = require('fs');
let text = fs.readFileSync('GoogleAppsScript/index.html', 'utf8');
text = text.replace(/<script>[\s\S]*?document\.addEventListener\("DOMContentLoaded"[\s\S]*?<\/script>/, `<script>
      document.addEventListener("DOMContentLoaded", function() {
        var sessionId = localStorage.getItem('simengajar_session_id');
        if(sessionId) {
            if(typeof google !== 'undefined' && google.script) {
                showLoading('Memeriksa sesi...');
                google.script.run
                    .withSuccessHandler(function(res) {
                        hideLoading();
                        if(res.success) {
                            currentUser = res.session;
                            loadPage('dashboard');
                        } else {
                            localStorage.removeItem('simengajar_session_id');
                            currentUser = null;
                            document.getElementById('app').innerHTML = '<?!= include("login"); ?>';
                            if (typeof initLogin === 'function') initLogin();
                        }
                    })
                    .withFailureHandler(function(err) {
                        hideLoading();
                        document.getElementById('app').innerHTML = '<?!= include("login"); ?>';
                        if (typeof initLogin === 'function') initLogin();
                    })
                    .checkSession(sessionId);
            } else {
                // Fallback Preview Lokal
                currentUser = { namaGuru: 'Guru Tester', status: 'Aktif' };
                loadPage('dashboard');
            }
        } else {
            document.getElementById('app').innerHTML = '<?!= include("login"); ?>';
            if (typeof initLogin === 'function') initLogin();
        }
      });
    </script>`);
fs.writeFileSync('GoogleAppsScript/index.html', text);
