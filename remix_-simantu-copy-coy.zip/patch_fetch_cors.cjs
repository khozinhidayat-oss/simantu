const fs = require('fs');
let html = fs.readFileSync('GoogleAppsScript/utils.js.html', 'utf8');

html = html.replace(/fetch\(GAS_API_URL, \{/g, `
if (!GAS_API_URL) {
    console.error("GAS_API_URL is missing");
    throw new Error("GAS_API_URL belum diatur. Silakan set di localStorage.");
}
fetch(GAS_API_URL, {
    redirect: "follow",
`);

fs.writeFileSync('GoogleAppsScript/utils.js.html', html);
