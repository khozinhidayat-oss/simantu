const fs = require('fs');
let content = fs.readFileSync('GoogleAppsScript/pengaturan.js.html', 'utf8');

const regex = /document\.getElementById\('([a-zA-Z0-9\-_]+)'\)\.textContent = ([^;]+);/g;

content = content.replace(regex, "const el_$1 = document.getElementById('$1'); if(el_$1) el_$1.textContent = $2;");

// and for innerText
const regex2 = /document\.getElementById\('([a-zA-Z0-9\-_]+)'\)\.innerText = ([^;]+);/g;
content = content.replace(regex2, "const el_$1 = document.getElementById('$1'); if(el_$1) el_$1.innerText = $2;");

fs.writeFileSync('GoogleAppsScript/pengaturan.js.html', content);
